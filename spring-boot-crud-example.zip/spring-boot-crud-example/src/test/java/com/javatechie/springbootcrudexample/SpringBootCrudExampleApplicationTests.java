package com.javatechie.springbootcrudexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
